//stack unwinding
#include<iostream>
using namespace std;
//a sample function f1 that throws an int exception
void f1()throw(int)
{
    cout<<"\nf1() start";
    throw 3;
    cout<<"\n f1() end";
}
//another function f2() that calls f1()
void f2()throw(int)
{
    cout<<"\n f2() start";
    f1();
    cout<<"\n f2() end";
}
//f3 calls f2() and f1() and handles exception thrown by f1()
void f3()
{
    cout<<"f3() start";
    try
    {
        f2();
    }
    catch(int i)
    {
        cout<<"\n caught exception"<<i;
    }
    cout<<"/n f3() end";
    }
    int main()
    {
        f3();
        return 0;
    }