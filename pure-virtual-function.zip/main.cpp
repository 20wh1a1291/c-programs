//pure virtual functions
#include<iostream>
using namespace std;
class A {
   public:
      virtual void s() = 0; // Pure Virtual Function
};

class D:public A {
   public:
      void s() {
         cout << "Virtual Function in Derived class\n";
      }
};

int main() {
   A *b;
   D dobj;
   b = &dobj;
   b->s();
}