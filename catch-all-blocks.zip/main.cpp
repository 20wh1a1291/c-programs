//exception using catch all block
#include<iostream>
using namespace std;
int main()
{
    int a,b;
    cout<<"enter values of a and b";
    cin>>a>>b;
    try
    {
        if(b==0)
        throw b;
        else if(b<0)
        throw "b cannot be negetive";
        else
        cout<<"result of a/b = "<<(a/b);
    }
    catch(int b)
    {
        cout<<"b cannot be zero";
    }
    catch(...)
    {
        cout<<"unknown exception";
    }
    return 0;
}
