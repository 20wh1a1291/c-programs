//class type exceptions
#include<iostream>
using namespace std;
class exception
{
    public:
    char str_w[80];
    int w;
    exception()
    {
        *str_w=0;w=0;
    }
    exception(char*s, int e)
    {
        strcpy(str_w,s);
        w=e;
    }
};
int main()
{
    int i;
    try
    {
        cout<<"enter a positive no";
        cin>>i;
        if(i<0)
        throw exception("not positive",i);
    }
    catch(exception e)
    {
        cout<<e.str_w<<":";
        cout<<e.w<<"\n";
    }
    return 0;
}
