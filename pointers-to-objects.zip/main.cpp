//pointers to objects
#include<iostream>
using namespace std;
class a
{
    int b;
    public:
    void get()
    {
        cout<<"enter value of b";
        cin>>b;
    }
    void show()
    {
        cout<<"b="<<b<<"\n";
    }
};
int main()
{
    a x;
    a*ptr=new a[10];
    x.get();
    x.show();
    for(int i=0;i<10;i++)
    {
        ptr->get();
        ptr->show();
    }
    return 0;
}
