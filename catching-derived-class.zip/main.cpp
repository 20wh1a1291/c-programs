//catching derived class
#include<iostream>
using namespace std;
class B
{
    
};
class D:public B
{
    
};
D derived;

    try
{
    throw derived;
}
catch(B b)
{
  cout<<"caught a base class\n";  
}
catch(D d)
{
    cout<<"not excecute\n";
}
return 0;
}